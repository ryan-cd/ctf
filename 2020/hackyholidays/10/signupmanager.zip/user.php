<?php
//DO NOT DELETE THE BELOW LINE
if( !isset($page) ) die("You cannot access this page directly"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>SignUp Manager - User Area</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
<div class="container" style="margin-top:20px">
    <h1 class="text-center" style="margin:0;padding:0">User Area</h1>
</div>
</body>
</html>
